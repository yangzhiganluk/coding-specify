/**
 * Created by lollipop on 2017/12/18
 */
$(".press").niceScroll();